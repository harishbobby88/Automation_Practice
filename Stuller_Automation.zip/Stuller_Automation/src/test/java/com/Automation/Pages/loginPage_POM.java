package com.Automation.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginPage_POM {

	protected WebDriver driver;

	private By login_button = By.xpath("//div//li[@id='Account']");
	private By txt_userName = By.xpath("//input[@placeholder='Username...']");
	private By txt_Password = By.xpath("//input[@placeholder='Password...']");
	private By logIn = By.xpath("//button[@type='submit']");
	private By elementToCheck = By.xpath("//span[text()='Showcase']");

	public void enterUserName(String Username) {
		driver.findElement(txt_userName).sendKeys(Username);
	}

	public void enterPassword(String password) {
		driver.findElement(txt_Password).sendKeys(password);
	}

	public loginPage_POM(WebDriver driver) {
		this.driver = driver;
	}

	public void click_login() {
		driver.findElement(login_button).click();
	}

	public void login() {
		driver.findElement(logIn).click();
	}

}
