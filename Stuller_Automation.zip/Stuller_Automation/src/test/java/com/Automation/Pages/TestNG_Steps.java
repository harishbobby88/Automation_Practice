package com.Automation.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestNG_Steps {

	public static WebDriver driver = null;

	@BeforeSuite()
	public void login_TC_001() throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("https://www.stuller.com/Band-Builder");
		Thread.sleep(5000);
		WebElement loginButton = driver.findElement(By.xpath("//div//li[@id='Account']"));
		loginButton.click();
		Thread.sleep(2000);
		WebElement userName = driver.findElement(By.xpath("//input[@placeholder='Username...']"));
		userName.sendKeys("stullerqa58392");
		Thread.sleep(2000);
		WebElement password = driver.findElement(By.xpath("//input[@placeholder='Password...']"));
		password.sendKeys("j1Vbe7nTi2");
		Thread.sleep(2000);
		WebElement logIn = driver.findElement(By.xpath("//button[@type='submit']"));
		logIn.click();
		Thread.sleep(2000);
	}

	@Test()
	public void login_Check_TC_002() throws InterruptedException {

		WebElement elementToCheck = driver.findElement(By.xpath("//span[text()='Showcase']"));
		// Check if the element is displayed
		if (elementToCheck.isDisplayed()) {
			System.out.println("Element is visible on the web page.");
		} else {
			System.out.println("Element is not visible on the web page.");
		}
	}

	@AfterSuite()
	public void login_Check_TC_003() throws InterruptedException {

		driver.close();
	}

}
