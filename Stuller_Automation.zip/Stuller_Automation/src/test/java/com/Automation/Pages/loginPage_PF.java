//package com.Automation.Pages;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.PageFactory;
//
//public class loginPage_PF {
//
//	
//
//	@FindBy(xpath = "//div//li[@id='Account']")
//	WebElement login_button;
//
//	@FindBy(xpath = "//input[@placeholder='Username...']")
//	WebElement txt_userName; 
//
//	@FindBy(xpath = "//input[@placeholder='Password...']")
//	WebElement txt_Password;
//
//	@FindBy(xpath = "//button[@type='submit']")
//	WebElement btn_logIn;
//
//	@FindBy(xpath = "//span[text()='Showcase']")
//	public WebElement elementToCheck;
//	
//	public static WebDriver driver;
//
//	public loginPage_PF(WebDriver driver) {
//		this.driver = driver;
//		PageFactory.initElements(driver, loginPage_PF.class);
//	}
//
//	public void enterUserName(String Username) {
//		txt_userName.sendKeys(Username);
//	}
//
//	public void enterPassword(String password) {
//		txt_Password.sendKeys(password);
//	}
//
//	public void click_login() {
//		login_button.click();
//	}
//
//	public void login() {
//		btn_logIn.click();
//	}
//
//}
