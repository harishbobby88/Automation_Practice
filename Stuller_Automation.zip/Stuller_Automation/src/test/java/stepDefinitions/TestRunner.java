package stepDefinitions;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources/Features", glue = { "stepDefinitions" }, monochrome = true, plugin = {
		"pretty", "json:target/JSON Reports/JsonReport.json", "html:target/HTML Reports/HtmlReports.html",
		"junit:target/JUnit Reports/JUnitReports.xml" })
public class TestRunner {

}
