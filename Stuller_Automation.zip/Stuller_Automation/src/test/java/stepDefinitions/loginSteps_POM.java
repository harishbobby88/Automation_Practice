package stepDefinitions;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.Automation.Pages.loginPage_POM;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class loginSteps_POM {
	public static WebDriver driver = null;
	loginPage_POM login;

	@Given("user is on the login page")
	public void user_is_on_the_login_page() throws Exception {
		ChromeOptions options = new ChromeOptions();
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("https://www.stuller.com/Band-Builder");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
	}

	@And("clicks on login button")
	public void clicks_on_login_button() throws Exception {
		//login.click_login();
		WebElement loginButton = driver.findElement(By.xpath("//div//li[@id='Account']"));
		loginButton.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	@When("^user enters (.*) and (.*)$")
	public void user_enters_username_and_password(String username, String password) throws Exception {
		login = new loginPage_POM(driver);
		login.enterUserName(username);
		login.enterPassword(password);
		Thread.sleep(2000);
		WebElement logIn = driver.findElement(By.xpath("//button[@type='submit']"));
		login.login();
		//logIn.click();
		Thread.sleep(2000);
	}

	@Then("user is navigated to homepage")
	public void user_is_navigated_to_homepage() {
		WebElement elementToCheck = driver.findElement(By.xpath("//span[text()='Showcase']"));
		// Check if the element is displayed
		if (elementToCheck.isDisplayed()) {
			System.out.println("Element is visible on the web page.");
		} else {
			System.out.println("Element is not visible on the web page.");
		}
	}

	@Then("I close the browser")
	public void i_close_the_browser() {
		driver.quit();
	}
}
